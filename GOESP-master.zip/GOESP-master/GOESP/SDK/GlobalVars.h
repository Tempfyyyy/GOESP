#pragma once

struct GlobalVars {
    float realtime;
    int framecount;
    float absoluteFrameTime;
    float absoluteFrameStartTimestddev;
    float currenttime;
    float frametime;
    int maxClients;
    int tickCount;
    float intervalPerTick;
};
