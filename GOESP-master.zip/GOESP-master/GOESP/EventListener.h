#pragma once

namespace EventListener
{
    void init() noexcept;
    void remove() noexcept;
}
